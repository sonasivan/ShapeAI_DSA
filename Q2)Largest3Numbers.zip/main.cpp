/* Write a program to find the largest number among three numbers entered by the user. */

#include <iostream>  
using namespace std;  
int main()  
{
  int x,y,z;
  cout << "Enter three different numbers:";
  cin >> x >> y >> z;
  if(x > y)
  {
    if(x > z)
    cout << "The largest number is: "<< x;
    else
    cout << "The largest number is: "<< z;
  }
  else
  {
    if(y > z)
    cout << "The largest number is: "<< y;
    else
    cout << "The largest number is: "<< z;
  }
  return 0;
}